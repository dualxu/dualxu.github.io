---
layout: post
title: Jekyll - Definition
key: 20160505
tags:
  - Jekyll
  - English
---

kramdown
: A Markdown-superset converter

Maruku
:     Another Markdown-superset converter

<!--more-->

**markdown:**

    kramdown
    : A Markdown-superset converter

    Maruku
    :     Another Markdown-superset converter